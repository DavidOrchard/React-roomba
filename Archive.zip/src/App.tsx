import React from 'react';
import './App.css';
import {BoardView} from './components/BoardView';

function App() {
  return (
    <div className="App">
        <p>
          Roomba fun
        </p>
        <BoardView />
    </div>
  );
}

export default App;
